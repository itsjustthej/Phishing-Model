#!/usr/bin/env python3
"""
Phishing Email Detection Model
===============================

A scikit-learn pipeline that classifies emails as "Phishing" or "Safe"
using a mix of TF-IDF text features and hand-engineered structural
features (URL patterns, urgency keywords, punctuation, etc.).

If you don't have a labeled dataset, this script generates a synthetic
one (template-based, with randomized variation) so the whole pipeline
runs end to end out of the box. Swap in a real dataset any time with
--data (see "Bring your own dataset" below).

Usage
-----
    python3 phishing_detector.py                        # synthetic data, quick demo
    python3 phishing_detector.py --n-samples 2000        # bigger synthetic dataset
    python3 phishing_detector.py --data emails.csv       # your own dataset
    python3 phishing_detector.py --model logreg          # logreg | random_forest (default)

Bring your own dataset
-----------------------
--data expects a CSV with at least two columns:
    text  : the raw email text (subject + body is fine combined)
    label : "phishing" / "safe"   (or 1 / 0)

A well-known public option for real data is the Kaggle "Phishing Email
Detection" dataset or the Nazario phishing corpus + Enron ham corpus —
search for those if you want to train on real-world email text instead
of the synthetic set generated here.

Outputs
-------
    - Console: accuracy, precision/recall/F1, confusion matrix
    - confusion_matrix.png   : heatmap of the confusion matrix
    - feature_importance.png : which features drove the decision (random_forest only)
    - phishing_model.joblib  : the trained pipeline, ready to reuse
"""

import argparse
import re
import random
import sys

import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import RandomForestClassifier
from sklearn.pipeline import Pipeline, FeatureUnion
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.metrics import (
    accuracy_score, classification_report, confusion_matrix,
    ConfusionMatrixDisplay, roc_auc_score
)
import joblib


# ---------------------------------------------------------------------------
# 1. Synthetic dataset generator (used when --data isn't provided)
# ---------------------------------------------------------------------------

URGENCY_PHRASES = [
    "Your account will be suspended within 24 hours",
    "Immediate action required to avoid account closure",
    "Verify your identity now or lose access",
    "This is your final notice",
    "Unusual sign-in activity detected on your account",
    "Your payment could not be processed",
    "Click below to confirm your details before it's too late",
    "Your account has been temporarily locked for security reasons",
    "Act now to claim your reward before it expires",
    "We noticed a problem with your billing information",
]

PHISHING_SUBJECTS = [
    "Urgent: Verify Your Account Now",
    "Action Required: Suspicious Login Detected",
    "Your Package Could Not Be Delivered",
    "Payment Failed - Update Your Information",
    "You've Won a Prize! Claim Now",
    "Security Alert: Unusual Activity",
    "Final Notice: Account Suspension Pending",
    "Confirm Your Identity to Continue",
]

PHISHING_DOMAINS = [
    "secure-login-update.com", "paypa1-verify.net", "amaz0n-support.com",
    "account-alert-service.info", "bank0famerica-secure.com", "192.168.44.21",
    "apple-id-confirm.co", "netfIix-billing.com", "microsoft-support-verify.xyz",
]

PHISHING_CLOSERS = [
    "Click here immediately to verify: {url}",
    "Please confirm your details at {url} within 24 hours.",
    "Follow this link to avoid suspension: {url}",
    "Log in now to secure your account: {url}",
]

LEGIT_SUBJECTS = [
    "Your monthly statement is ready",
    "Team meeting notes from Tuesday",
    "Reminder: project deadline next week",
    "Your order has shipped",
    "Weekly newsletter: product updates",
    "Invoice #4521 attached",
    "Welcome to the team!",
    "Follow-up from our call yesterday",
]

LEGIT_BODIES = [
    "Hi, just wanted to follow up on the notes from our meeting earlier this week. Let me know if I missed anything.",
    "Attached is the invoice for last month's services. Let us know if you have any questions about the charges.",
    "Your order has shipped and should arrive within 3-5 business days. You can track it using the link in your account dashboard.",
    "Here's a quick summary of what's new this month, along with a few upcoming events you might be interested in.",
    "Thanks for joining the call today. I've summarized the action items below and will follow up next week.",
    "Reminder that the quarterly report is due by Friday. Let me know if you need an extension.",
    "Welcome aboard! Your onboarding materials are attached, and your manager will reach out this week to set up an intro call.",
    "Just checking in to see how things are going with the project. Happy to jump on a call if that's easier.",
]

LEGIT_DOMAINS = [
    "company.com", "docs.google.com", "github.com", "notion.so",
    "slack.com", "zoom.us", "yourbank.com", "amazon.com",
]


def _make_url(domain, https=True):
    scheme = "https" if https else "http"
    path = random.choice(["", "/login", "/account/verify", "/update", "/track"])
    return f"{scheme}://{domain}{path}"


def generate_phishing_email():
    subject = random.choice(PHISHING_SUBJECTS)
    urgency = random.choice(URGENCY_PHRASES)
    domain = random.choice(PHISHING_DOMAINS)
    url = _make_url(domain, https=random.random() > 0.4)
    closer = random.choice(PHISHING_CLOSERS).format(url=url)
    n_extra_urls = random.randint(0, 2)
    extra_urls = " ".join(_make_url(random.choice(PHISHING_DOMAINS)) for _ in range(n_extra_urls))
    exclaim = "!" * random.randint(0, 3)
    body = f"{urgency}{exclaim} {closer} {extra_urls}".strip()
    if random.random() > 0.5:
        body = body.upper()[:20] + body[20:]  # occasional shouty opener
    return f"Subject: {subject}\n\n{body}"


def generate_legit_email():
    subject = random.choice(LEGIT_SUBJECTS)
    body = random.choice(LEGIT_BODIES)
    if random.random() > 0.6:
        domain = random.choice(LEGIT_DOMAINS)
        body += f" More details here: {_make_url(domain, https=True)}"
    return f"Subject: {subject}\n\n{body}"


def build_synthetic_dataset(n_samples, seed=42):
    random.seed(seed)
    n_each = n_samples // 2
    rows = []
    for _ in range(n_each):
        rows.append({"text": generate_phishing_email(), "label": "phishing"})
    for _ in range(n_each):
        rows.append({"text": generate_legit_email(), "label": "safe"})
    df = pd.DataFrame(rows).sample(frac=1, random_state=seed).reset_index(drop=True)
    return df


# ---------------------------------------------------------------------------
# 2. Hand-engineered structural features
# ---------------------------------------------------------------------------

URL_RE = re.compile(r"https?://[^\s]+")
IP_URL_RE = re.compile(r"https?://\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}")
SUSPICIOUS_KEYWORDS = [
    "verify", "urgent", "suspend", "immediately", "confirm", "click here",
    "password", "update your", "act now", "limited time", "winner", "prize",
    "security alert", "unusual activity", "final notice", "locked",
]
KNOWN_BRANDS = ["paypal", "amazon", "apple", "microsoft", "netflix", "bank"]


class EmailFeatureExtractor(BaseEstimator, TransformerMixin):
    """Turns raw email text into a numeric feature matrix."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        rows = []
        for text in X:
            text_l = text.lower()
            urls = URL_RE.findall(text)
            rows.append({
                "num_urls": len(urls),
                "has_ip_url": int(bool(IP_URL_RE.search(text))),
                "num_suspicious_keywords": sum(kw in text_l for kw in SUSPICIOUS_KEYWORDS),
                "num_exclamations": text.count("!"),
                "pct_uppercase": self._pct_uppercase(text),
                "email_length": len(text),
                "mentions_known_brand": int(any(b in text_l for b in KNOWN_BRANDS)),
                "brand_with_odd_domain": self._brand_domain_mismatch(text_l, urls),
                "num_digits_in_domain": self._digits_in_domain(urls),
            })
        return pd.DataFrame(rows)

    @staticmethod
    def _pct_uppercase(text):
        letters = [c for c in text if c.isalpha()]
        if not letters:
            return 0.0
        upper = sum(c.isupper() for c in letters)
        return upper / len(letters)

    @staticmethod
    def _brand_domain_mismatch(text_l, urls):
        # Flags e.g. "paypal" mentioned in text but URL domain isn't paypal.com
        mentioned = [b for b in KNOWN_BRANDS if b in text_l]
        if not mentioned or not urls:
            return 0
        for url in urls:
            for brand in mentioned:
                if brand in url.lower() and f"{brand}.com" not in url.lower():
                    return 1
        return 0

    @staticmethod
    def _digits_in_domain(urls):
        total = 0
        for url in urls:
            m = re.search(r"://([^/]+)", url)
            if m:
                domain = m.group(1)
                total += sum(c.isdigit() for c in domain)
        return total


class TextColumnSelector(BaseEstimator, TransformerMixin):
    """Pulls the raw text column out for the TF-IDF branch of the pipeline."""

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X


# ---------------------------------------------------------------------------
# 3. Pipeline construction
# ---------------------------------------------------------------------------

def build_pipeline(model_name="random_forest"):
    features = FeatureUnion([
        ("tfidf", Pipeline([
            ("select", TextColumnSelector()),
            ("vectorize", TfidfVectorizer(max_features=500, stop_words="english", ngram_range=(1, 2))),
        ])),
        ("structural", EmailFeatureExtractor()),
    ])

    if model_name == "logreg":
        clf = LogisticRegression(max_iter=1000)
    else:
        clf = RandomForestClassifier(n_estimators=200, random_state=42)

    return Pipeline([
        ("features", features),
        ("clf", clf),
    ])


# ---------------------------------------------------------------------------
# 4. Evaluation / reporting
# ---------------------------------------------------------------------------

def plot_confusion_matrix(y_test, y_pred, labels, out_path):
    cm = confusion_matrix(y_test, y_pred, labels=labels)
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=labels)
    fig, ax = plt.subplots(figsize=(5, 5))
    disp.plot(ax=ax, cmap="Blues", colorbar=False, values_format="d")
    ax.set_title("Phishing Detector — Confusion Matrix")
    plt.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return cm


def plot_feature_importance(pipeline, out_path, top_n=15):
    clf = pipeline.named_steps["clf"]
    if not hasattr(clf, "feature_importances_"):
        return False
    features = pipeline.named_steps["features"]
    tfidf_names = list(features.transformer_list[0][1].named_steps["vectorize"].get_feature_names_out())
    structural_names = ["num_urls", "has_ip_url", "num_suspicious_keywords", "num_exclamations",
                         "pct_uppercase", "email_length", "mentions_known_brand",
                         "brand_with_odd_domain", "num_digits_in_domain"]
    all_names = tfidf_names + structural_names

    importances = clf.feature_importances_
    order = np.argsort(importances)[::-1][:top_n]
    top_names = [all_names[i] for i in order]
    top_vals = [importances[i] for i in order]

    fig, ax = plt.subplots(figsize=(7, 5))
    ax.barh(top_names[::-1], top_vals[::-1], color="#4F7CFF")
    ax.set_title(f"Top {top_n} Features Driving Predictions")
    ax.set_xlabel("Importance")
    plt.tight_layout()
    fig.savefig(out_path, dpi=150)
    plt.close(fig)
    return True


# ---------------------------------------------------------------------------
# 5. Main
# ---------------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser(description="Train and evaluate a phishing email classifier.")
    parser.add_argument("--data", default=None,
                         help="Path to a CSV with 'text' and 'label' columns. If omitted, a synthetic dataset is generated.")
    parser.add_argument("--n-samples", type=int, default=1200, help="Size of the synthetic dataset (if --data not given)")
    parser.add_argument("--model", choices=["random_forest", "logreg"], default="random_forest")
    parser.add_argument("--test-size", type=float, default=0.25)
    parser.add_argument("--output-dir", default=".")
    args = parser.parse_args()

    if args.data:
        df = pd.read_csv(args.data)
        if "text" not in df.columns or "label" not in df.columns:
            print("CSV must contain 'text' and 'label' columns.")
            sys.exit(1)
        df["label"] = df["label"].apply(
            lambda v: "phishing" if str(v).strip().lower() in ("phishing", "1", "spam", "phish") else "safe"
        )
        print(f"Loaded {len(df)} emails from {args.data}")
    else:
        df = build_synthetic_dataset(args.n_samples)
        print(f"No --data provided: generated a synthetic dataset of {len(df)} emails "
              f"({(df.label == 'phishing').sum()} phishing / {(df.label == 'safe').sum()} safe).")
        print("This is for demonstrating the pipeline end-to-end. Swap in a real dataset with --data for production use.\n")

    min_class_count = df["label"].value_counts().min()
    can_stratify = min_class_count >= 2 and int(len(df) * args.test_size) >= df["label"].nunique()
    if not can_stratify:
        print(f"Warning: dataset too small to stratify the split (smallest class has "
              f"{min_class_count} example(s)). Falling back to a plain random split — "
              f"results on such a tiny dataset are illustrative only, not a reliable accuracy estimate.\n")
    X_train, X_test, y_train, y_test = train_test_split(
        df["text"], df["label"], test_size=args.test_size, random_state=42,
        stratify=df["label"] if can_stratify else None
    )

    pipeline = build_pipeline(args.model)
    print(f"Training {args.model} classifier on {len(X_train)} emails...")
    pipeline.fit(X_train, y_train)

    y_pred = pipeline.predict(X_test)
    acc = accuracy_score(y_test, y_pred)

    print(f"\n=== Results on {len(X_test)} held-out emails ===")
    print(f"Accuracy: {acc:.4f}\n")
    print("Classification report:")
    print(classification_report(y_test, y_pred, digits=3))

    labels = sorted(df["label"].unique())
    cm = plot_confusion_matrix(y_test, y_pred, labels, f"{args.output_dir}/confusion_matrix.png")
    print("Confusion matrix (rows = actual, cols = predicted):")
    print(pd.DataFrame(cm, index=[f"actual_{l}" for l in labels], columns=[f"pred_{l}" for l in labels]))

    if hasattr(pipeline.named_steps["clf"], "predict_proba"):
        y_scores = pipeline.predict_proba(X_test)[:, list(pipeline.classes_).index("phishing")]
        y_true_bin = (y_test == "phishing").astype(int)
        auc = roc_auc_score(y_true_bin, y_scores)
        print(f"\nROC-AUC: {auc:.4f}")

    made_importance_plot = plot_feature_importance(pipeline, f"{args.output_dir}/feature_importance.png")

    joblib.dump(pipeline, f"{args.output_dir}/phishing_model.joblib")

    print(f"\nSaved:")
    print(f"  {args.output_dir}/confusion_matrix.png")
    if made_importance_plot:
        print(f"  {args.output_dir}/feature_importance.png")
    print(f"  {args.output_dir}/phishing_model.joblib")


if __name__ == "__main__":
    main()
